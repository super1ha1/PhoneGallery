package com.vinako.phonegallery.storage;

import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.TextView;

/**
 * Created by Khue on 15/5/2015.
 */
public class ViewHolder {
        protected TextView category;
        protected TextView  status;
        protected ImageView icon;
        protected CheckBox checkBox;
    public ViewHolder(){

    }
}
